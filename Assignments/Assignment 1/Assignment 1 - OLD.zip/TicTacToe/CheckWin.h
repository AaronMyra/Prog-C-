//
// Created by student on 21/09/19.
//

#ifndef TICTACTOE_CHECKWIN_H
#define TICTACTOE_CHECKWIN_H
bool checkWin(char (*gridPtr)[3][3], char letter, int turn);
#endif //TICTACTOE_CHECKWIN_H



