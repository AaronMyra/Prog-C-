//
// Created by student on 21/09/19.
//

#ifndef TICTACTOE_BLOCK_H
#define TICTACTOE_BLOCK_H
bool checkBlock(char (*gridPtr)[3][3], char , char , char*);
#endif //TICTACTOE_BLOCK_H

