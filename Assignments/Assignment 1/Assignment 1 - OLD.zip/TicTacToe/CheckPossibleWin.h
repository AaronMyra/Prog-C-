//
// Created by student on 22/09/19.
//

#ifndef TICTACTOE_CHECKPOSSIBLEWIN_H
#define TICTACTOE_CHECKPOSSIBLEWIN_H
bool checkPossibleWin(char (*gridPtr)[3][3], char userLetter, char compLetter);
#endif //TICTACTOE_CHECKPOSSIBLEWIN_H

