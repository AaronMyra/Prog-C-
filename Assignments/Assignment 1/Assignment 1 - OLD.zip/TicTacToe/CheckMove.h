//
// Created by student on 21/09/19.
//

#ifndef TICTACTOE_CHECKMOVE_H
#define TICTACTOE_CHECKMOVE_H
bool userMoveCheck(int,char (*gridPtr)[3][3],char,char);
bool compMoveCheck(char (*gridPtr)[3][3],int,int,char,char);
#endif //TICTACTOE_CHECKMOVE_H

