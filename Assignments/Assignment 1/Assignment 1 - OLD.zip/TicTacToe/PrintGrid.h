//
// Created by student on 21/09/19.
//

#ifndef TICTACTOE_PRINTGRID_H
#define TICTACTOE_PRINTGRID_H
void printGrid(char (*gridPtr)[3][3],int,int);
#endif //TICTACTOE_PRINTGRID_H

