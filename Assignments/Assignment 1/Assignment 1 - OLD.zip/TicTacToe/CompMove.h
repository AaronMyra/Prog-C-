//
// Created by student on 21/09/19.
//

#ifndef TICTACTOE_COMPMOVE_H
#define TICTACTOE_COMPMOVE_H
void compMove(char (*gridPtr)[3][3],char,char,int,char*);
#endif //TICTACTOE_COMPMOVE_H

