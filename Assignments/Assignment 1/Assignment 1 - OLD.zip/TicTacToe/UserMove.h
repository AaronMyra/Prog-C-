//
// Created by student on 21/09/19.
//

#ifndef TICTACTOE_USERMOVE_H
#define TICTACTOE_USERMOVE_H
void userMove(char (*gridPtr)[3][3],char,char);
#endif //TICTACTOE_USERMOVE_H

